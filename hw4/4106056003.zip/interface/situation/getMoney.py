# -*- coding: utf-8 -*-

money = 100000

def printMoney():
	print( "目前的資金：", money)